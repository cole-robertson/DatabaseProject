﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int a = 1;
        int total = 50;
        int classes;
        int g = 1;
        int count = 0;
        string name;
        string[] names = { "Leota",
"Theressa",
"Ardelia",
"Angla",
"Kathern",
"Arden",
"Carmelia",
"Christinia",
"Jacquie",
"Arlie",
"Tula",
"Adan",
"Marylin",
"Paulette",
"Micheal",
"Kathie",
"Chadwick",
"Fredric",
"Katharina",
"Keiko",
"Twanna",
"Eveline",
"Karie",
"Freda",
"Kaylene",
"Keeley",
"Marica",
"Sima",
"Randi",
"Jackeline",
"Ilda",
"Emmaline",
"Georgeann",
"Mariah",
"Bula",
"Garfield",
"Malik",
"Pamula",
"Leeanna",
"Nakita",
"Thora",
"Jessika",
"Brynn",
"Tomas",
"Camille",
"Dortha",
"Felisa",
"Nicholle",
"Lonnie",
"Taisha"};



        // Press Button 1 to Create random values used to fill Reviews table
        // Change classes variable above to get desired number of classes to review
        private void button1_Click(object sender, EventArgs e)
        {

            while (g < total)
            {
                using (StreamWriter sw = new StreamWriter("C:\\Users\\williamy\\Desktop\\script" + a + ".txt"))
                {
                    Random r = new Random();
                    Random r2 = new Random();
                    Random r3 = new Random();
                    Random r4 = new Random();
                    int k;

                    for (int i = 1000; i > 0; i--)
                    {


                        int p = r2.Next(3, 7);
                        for (k = 1; k < p; k++)
                        {
                            int j = r.Next(1, 6);
                            int z = r3.Next(1, 10);
                            int y = r4.Next(1, 50);
                            if (z >= 5)
                            {
                                sw.Write("(" + g + ", N'Anonymous', " + j);
                            }
                            
                            else {
                                name = names[y];
                                sw.Write("(" + g + ", N'" + name + "', " + j);
                            }
                            if (j == 1) sw.WriteLine(", N'Bad!'),");
                            else if (j == 2) sw.WriteLine(", N'Eh!'),");
                            else if (j == 3) sw.WriteLine(", N'Ok!'),");
                            else if (j == 4) sw.WriteLine(", N'Good!'),");
                            else if (j == 5) sw.WriteLine(", N'Great!'),");
                            else sw.WriteLine(", N'Unknown'),");

                        }
                        i = i - p;
                        g++;
                        if (g > total) { i = 0; }
                    }



                    sw.Close();
                }
                a++;
            }




        }
        

        // Press Button 2 to create text file filled with entries to use to populate StudentClass table
        private void button2_Click(object sender, EventArgs e)
        {


            using (StreamWriter sw = new StreamWriter("C:\\Users\\williamy\\Desktop\\enrollers" + a + ".txt"))
            {
                Random r5 = new Random();
                Random r6 = new Random();


                int p1 = r5.Next(1, 3);

                for (int j = 90; j < 120; j++)
                {
                    for (int i = p1; i > 0; i--)
                    {
                        int p2 = r6.Next(65, 103);

                        {
                            sw.WriteLine("(" + j + "," + p2 + "),");
                        }
                    }
                }



                sw.Close();
            }
        }
        
    }
}
